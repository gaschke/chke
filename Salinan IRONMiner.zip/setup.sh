#!/bin/bash
APPROOT=$(dirname $(readlink -e $0))

# If you want to run as another user, please modify \$UID to be owned by this user
if [[ "$UID" -ne '0' ]]; then
  echo "Error: You must run this script as root!"; exit 1
fi

uninstall_package() {
  systemctl stop iworker
  systemctl disable iworker
  rm -f /etc/systemd/system/iworker.service
  rm -rf $APPROOT/start_iworker.sh
  rm -rf $APPROOT/stop_iworker.sh
  rm -rf $APPROOT/iworkerwrapper
  rm -rf $APPROOT/iworker.log
}

while getopts "u" opt; do
  case "$opt" in
    u) echo "Uninstall iworker package..."
       uninstall_package
       echo "Done."
       exit 0
       ;;
    *) echo "Unknown option: \$opt"
       exit 1
       ;;
  esac
done

if [ ! -f $APPROOT/iworker.cfg ]; then
    echo -e "$APPROOT/iworker.cfg not found'\n"
    exit 1
fi
source $APPROOT/iworker.cfg

if [[ "$POOL" == "xxx.xxx.xxx.xxx:xxxx" || "$POOL" == "" ]]; then
    echo -e "Please edit the '$APPROOT/iworker.cfg'\n"
    exit 1
fi

if [[ ! -f $APPROOT/iworker ]]; then
    echo -e "iworker not found\n"
    exit 1
fi
chmod +x $APPROOT/iworker

cat << EOF > /etc/systemd/system/iworker.service
[Unit]
Description=Iworker Service
Documentation=https://www.secureweb3.com/
After=network-online.target
Wants=network-online.target

[Service]
User=root
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ExecStart=+$APPROOT/iworkerwrapper
Restart=on-failure
RestartPreventExitStatus=23

[Install]
WantedBy=multi-user.target
EOF

cat << SUPER-EOF > $APPROOT/iworkerwrapper
#!/bin/bash
set -o pipefail

source $APPROOT/iworker.cfg

if [[ "\$POOL" == "xxx.xxx.xxx.xxx:xxxx" || "\$POOL" == "" ]]; then
    echo -e "Please edit the '$APPROOT/iworker.cfg'\n"
    exit 1
fi

LOG_PATH="$APPROOT/iworker.log"
APP_PATH="$APPROOT/iworker"

cpu_affinity=(\$(nvidia-smi topo -m 2>/dev/null | awk -F'\t+| {2,}' '{for (i=1;i<=NF;i++) if(\$i ~ /CPU Affinity/) col=i; if (NR != 1 && \$0 ~ /^GPU/) print \$col}'))
gpu_num=\${#cpu_affinity[*]}

cat << EOF >> \$LOG_PATH
=============================================================================
Account name    : \$ACCOUNT_NAME
Pool            : \$POOL
Number of gpus  : \$gpu_num
=============================================================================
EOF

if [[ \$gpu_num -gt 0 ]]; then
    \$APP_PATH -g \$(echo \$(seq 0 \$((gpu_num-1))) | sed 's/ /,/g') -a "\$ACCOUNT_NAME" -p "\$POOL" >> \$LOG_PATH 2>&1
fi

SUPER-EOF
chmod +x $APPROOT/iworkerwrapper

cat << EOF > $APPROOT/start_iworker.sh
#!/bin/bash
sudo systemctl start iworker
EOF
chmod +x $APPROOT/start_iworker.sh

cat << EOF > $APPROOT/stop_iworker.sh
#!/bin/bash
sudo systemctl stop iworker
EOF
chmod +x $APPROOT/stop_iworker.sh

systemctl enable iworker
systemctl start iworker

